export enum MenuTypes {
  Internal = 'Internal',
  External = 'External',
}

export enum UrlFormats {
  Slug = 'SLUG',
  ShortId = 'SHORT_ID',
}
