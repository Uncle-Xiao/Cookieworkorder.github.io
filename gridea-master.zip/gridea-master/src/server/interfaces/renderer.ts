export interface IPagination {
  prev: string,
  next: string,
}
