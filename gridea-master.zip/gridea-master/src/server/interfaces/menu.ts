export interface IMenu {
  name: string
  index?: number
  openType: string
  link: string
}
