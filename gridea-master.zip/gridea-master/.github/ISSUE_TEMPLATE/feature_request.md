---
name: Feature Request
about: 想让我们为 Gridea 增加什么功能吗？
title: 'feat: '
labels: 'Feature Request'
assignees: ''

---

<!--
  你好！感谢你愿意考虑希望 Gridea 增加某个新功能。请花一点点时间尽量详细地回答以下基础问题。

  谢谢！
-->

## 概述

<!--
  对这个新功能的一段描述
-->

## 动机

<!--
  为什么你希望在 Gridea 中使用这个功能？
-->

## 详细解释

<!--
  详细描述这个新功能。

  如果这是一个小功能，你可以忽略这部分。
-->

